<template>
	<view>
		<view class="list-container">
			<view class="list-item" v-for="contact in contacts" :key="contact.id" @click="goToInterDetail(contact)">
				{{ contact.name }}
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				contacts: [{
						id: 1,
						name: '张三',
						phone: '1234567890',
						email: 'zhangsan@example.com',
						meeting: '周会'
					},
					{
						id: 2,
						name: '李四',
						phone: '0987654321',
						email: 'lisi@example.com',
						meeting: '月会'
					},
					// 更多联系人
				]
			}
		},
		methods: {
			goToInterDetail(contact) {
				uni.navigateTo({
					url: `/pages/me/InterDetail?data=${encodeURIComponent(JSON.stringify(contact))}`
				});
			}
		}
	}
</script>

<style>
	.list-container {
		width: 100%;
	}

	.list-item {
		width: 100%;
		padding: 10px;
		border-bottom: 1px solid #ccc;
		cursor: pointer;
	}
</style>