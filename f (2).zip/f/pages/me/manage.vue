<template>
	<view>
		<u-search placeholder="请输入客户名字" v-model="keyword" margin="10px" @confirm="searchUser"></u-search>
		<view v-if="filteredUsers.length">
			<view v-for="user in filteredUsers" :key="user.id" class="user-item">
				<text>{{ user.name }}</text>
			</view>
		</view>
		<view v-else>
			<text>没有找到用户</text>
		</view>
		<button class="add-user-btn" @click="addUser">添加</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				keyword: '',
				users: [{
						id: 1,
						name: 'Alice'
					},
					{
						id: 2,
						name: 'Bob'
					},
					{
						id: 3,
						name: 'Charlie'
					}
				]
			}
		},
		computed: {
			filteredUsers() {
				return this.users.filter(user => user.name.toLowerCase().includes(this.keyword.toLowerCase()));
			}
		},
		methods: {
			searchUser() {
				console.log('搜索用户:', this.keyword);
			},
			addUser() {
				console.log('添加用户信息');
				//添加打开新页面来添加用户
			}
		}
	}
</script>

<style>
	.add-user-btn {
		position: fixed;/*固定位置*/
		right: 10px;
		bottom: 10px;
		padding: 10px;
		background-color: #6191d3;
		color: white;
		border: none;
		border-radius: 10%;
		width: 25px;
		height: 40px;
		text-align: center;
		line-height: 15px;
		box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
		font-size: 10px;
		display: flex;
		justify-content: center;
		align-items: center;
	}
</style>