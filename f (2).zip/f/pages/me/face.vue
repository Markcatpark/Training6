<template>
	<view class="form-container">
		<u-form>
			<u-form-item label="姓名" label-width="150">
				<u-input placeholder="请输入姓名" type="text" v-model="userInfo.name"></u-input>
			</u-form-item>
			<u-form-item label="性别" label-width="150">
				<u-radio-group v-model="userInfo.gender" style="display: flex; flex-wrap: wrap;">
					<u-radio v-for="(item, index) in genderList" :key="index" :name="item.name" :disabled="item.disabled">
						{{ item.name }}
					</u-radio>
				</u-radio-group>
			</u-form-item>
			<u-form-item label="购买偏好" label-width="150">
				<u-input placeholder="请输入购买偏好" type="text" v-model="userInfo.purchasePreference"></u-input>
			</u-form-item>
			<u-form-item label="兴趣爱好" label-width="150">
				<u-input placeholder="请输入兴趣爱好" type="text" v-model="userInfo.hobbies"></u-input>
			</u-form-item>
			<u-form-item label="消费习惯" label-width="150">
				<u-input placeholder="请输入消费习惯" type="text" v-model="userInfo.spendingHabits"></u-input>
			</u-form-item>
			<u-form-item label="互动频率" label-width="150">
				<u-input placeholder="请输入互动频率" type="text" v-model="userInfo.interactionFrequency"></u-input>
			</u-form-item>
		</u-form>
		<u-button @click="generateProfile">生成客户画像</u-button>

		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				genderList: [
					{ name: '男', disabled: false },
					{ name: '女', disabled: false }
				],
				userInfo: {
					name: '',
					gender: '',
					purchasePreference: '',
					hobbies: '',
					spendingHabits: '',
					interactionFrequency: ''
				},
				profile: null
			};
		},
		methods: {
			generateProfile() {
				const needs = this.analyzeNeeds(this.userInfo);
				this.profile = {
					needs: needs
				};
			}
		}
	};
</script>

<style>
	.form-container {
		padding: 20px;
	}

	.u-form-item {
		margin-bottom: 15px;
	}

	.profile-container {
		margin-top: 20px;
		padding: 15px;
		border: 1px solid #ccc;
		border-radius: 4px;
		background-color: #f9f9f9;
	}

	.profile-title {
		font-size: 14px;
		font-weight: bold;
		margin-bottom: 5px;
	}

	.profile-text {
		font-size: 12px;
		line-height: 1.5;
	}
</style>
