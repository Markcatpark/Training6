<template>
	<view class="form-container">
		<u-form>
			<u-form-item label="姓名" label-width="150">
				<u-input placeholder="请输入姓名" type="text" v-model="yonghu.xingming"></u-input>
			</u-form-item>
			<u-form-item label="联系方式" label-width="150">
				<u-input placeholder="请输入电话" type="text" v-model="yonghu.dianhua"></u-input>
			</u-form-item>
			<u-form-item label="年龄" label-width="150">
				<u-radio-group v-model="radio" style="display: flex; flex-wrap: wrap;">
					<u-radio v-for="(item, index) in radioList" :key="index" :name="item.name"
						:disabled="item.disabled">
						{{ item.name }}
					</u-radio>
				</u-radio-group>
			</u-form-item>
			<u-form-item label="性别" label-width="150">
				<u-radio-group v-model="gender" style="display: flex; flex-wrap: wrap;">
					<u-radio v-for="(item, index) in genderList" :key="index" :name="item.name"
						:disabled="item.disabled">
						{{ item.name }}
					</u-radio>
				</u-radio-group>
			</u-form-item>
			<u-form-item label="城市" label-width="150">
				<u-input placeholder="请输入您所在的城市" type="number" v-model="yonghu.pianhao"></u-input>
			</u-form-item>
			<u-form-item label="身份" label-width="150">
				<u-radio-group v-model="role" style="display: flex; flex-wrap: wrap;">
					<u-radio v-for="(item, index) in roleList" :key="index" :name="item.name" :disabled="item.disabled">
						{{ item.name }}
					</u-radio>
				</u-radio-group>
			</u-form-item>
		</u-form>
		<u-button @click="submit">确定</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				radioList: [{
						name: '儿童',
						disabled: false
					},
					{
						name: '青少年',
						disabled: false
					},
					{
						name: '中年',
						disabled: false
					},
					{
						name: '老年',
						disabled: false
					}
				],
				radio: '',
				roleList: [{
						name: '学生',
						disabled: false
					},
					{
						name: '在职人员',
						disabled: false
					},
					{
						name: '退休人员',
						disabled: false
					}
				],
				role: '',
				genderList: [{
						name: '男',
						disabled: false
					},
					{
						name: '女',
						disabled: false
					}
				],
				gender: '',
				yonghu: {
					xingming: "",
					dianhua: "",
					jilu: "",
					pianhao: ''
				},
			}
		},
		methods: {
			submit() {
				console.log('提交数据:', this.yonghu, this.radio, this.role, this.gender);
				uni.navigateBack();
			}
		}
	}
</script>

<style>
	.form-container {
		padding: 12px;
	}

	button {
		padding: 10px 20px;
		background-color: #007aff;
		color: #fff;
		border: none;
		border-radius: 5px;
	}
</style>