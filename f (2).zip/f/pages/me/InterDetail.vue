<template>
	<view class="info-container">
		<view class="info-item"><text>姓名: {{ contact.name }}</text></view>
		<view class="info-item"><text>电话: {{ contact.phone }}</text></view>
		<view class="info-item"><text>邮件: {{ contact.email }}</text></view>
		<view class="info-item"><text>会议: {{ contact.meeting }}</text></view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				contact: {}
			}
		},
		onLoad(options) {
			if (options.data) {
				this.contact = JSON.parse(decodeURIComponent(options.data));
			}
		}
	}
</script>

<style>
	.info-container {
		display: flex;
		flex-direction: column;
		padding: 20px;
		/* 增加一些内边距 */
	}

	.info-item {
		margin-bottom: 10px;
		/* 为每项信息添加一些底部间距 */
	}
</style>