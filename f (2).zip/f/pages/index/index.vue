<template>
	<view class="container">
		<view class="menu">
			<view class="menu-item" @click="toggleSubMenu('customerRelations')">
				<image class="icon" src="/static/image/客户1.png" />
				<text class="text">客户关系管理</text>
			</view>
			<view class="sub-menu" v-if="activeMenu === 'customerRelations'">
				<view class="sub-menu-item" @click="goToManagePage">
					<image class="icon" src="/static/image/档案1.png" />
					<text class="text">客户档案管理</text>
				</view>
				<view class="sub-menu-item">
					<image class="icon" src="/static/image/价值观.png" />
					<text class="text">客户价值评估</text>
				</view>
			</view>
			<view class="menu-item" @click="goToFacePage">
				<image class="icon" src="/static/image/客户画像2.png" />
				<text class="text">客户画像</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				activeMenu: null,
			};
		},
		methods: {
			toggleSubMenu(menu) {
				this.activeMenu = this.activeMenu === menu ? null : menu;
			},
			goBack() {
				uni.navigateBack();
			},
			goToManagePage(){
				uni.navigateTo({
					url:"/pages/me/manage"
				})
			},
			goToInteractionPage(){
				uni.navigateTo({
					url:"/pages/me/interaction"
				})
			},
			goToFacePage(){
				uni.navigateTo({
					url:"/pages/me/detail"
				})
			}
		}
	};
</script>

<style>
	.container {
		padding: 5px;
	}

	.header {
		display: flex;
		align-items: center;
		margin-bottom: 16px;
	}

	.back-icon {
		font-size: 20px;
		margin-right: 8px;
		cursor: pointer;
	}

	.title {
		font-size: 24px;
		font-weight: bold;
	}

	.menu {
		display: flex;
		flex-direction: column;
	}

	.menu-item {
		display: flex;
		align-items: center;
		padding: 8px;
		border-bottom: 1px solid #ccc;
		cursor: pointer;
	}

	.sub-menu {
		padding-left: 30px;
	}

	.sub-menu-item {
		display: flex;
		align-items: center;
		padding: 8px 0;
	}

	.icon {
		width: 20px;
		height: 20px;
		margin-right: 12px;
	}

	.text {
		font-size: 13px;
	}
</style>