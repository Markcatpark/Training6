<template>
	<view class="rankings">
		<u-form>
			<u-form-item>
				<span class="title">业绩排行榜</span>
			</u-form-item>
			<u-form-item>
				<ul>
					<li v-for="(product, index) in productRankings" :key="product.id">
						<span>{{ index + 1 }}. {{ product.name }}</span>
						<span>{{ product.sales }}件</span>
					</li>
				</ul>
			</u-form-item>
		</u-form>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				productRankings: [{
						id: 1,
						name: '产品A',
						sales: 100
					},
					{
						id: 2,
						name: '产品B',
						sales: 80
					},
					{
						id: 3,
						name: '产品C',
						sales: 70
					},
					{
						id: 4,
						name: '产品D',
						sales: 60
					},
					{
						id: 5,
						name: '产品E',
						sales: 50
					}
				]
			}
		}
	}
</script>

<style scoped>
	.rankings {
		padding: 20px;
	}

	.title {
		font-size: 12px;
		font-weight: bold;
		display: block;
		margin-bottom: 1px;
	}

	.rankings ul {
		list-style: none;
		padding: 0;
	}

	.rankings li {
		margin-bottom: 10px;
	}
</style>