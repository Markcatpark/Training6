<template>
	<view class="container">
		<view class="menu">
			<!-- 销售数据分析 -->
			<!-- 修改 toggleSubMenu 方法，使其根据传入的菜单项名称切换相应布尔值的状态 -->
			<view class="menu-item" @click="toggleSubMenu('customerRelations')">
				<image class="icon" src="/static/数据分析.png" />
				<text class="text">销售数据分析</text>
			</view>

			<view class="sub-menu" v-if="activeMenu.customerRelations">
				<view class="sub-menu-item" @click="goToManagePage">
					<image class="icon" src="/static/产品分析.png" />
					<text class="text">产品销售分析</text>
				</view>
				<view class="sub-menu-item" @click="goToInteractionPage">
					<image class="icon" src="/static/王冠.png" />
					<text class="text">客户贡献度分析</text>
				</view>
			</view>

			<!-- 销售业绩评估 -->
			<view class="menu-item" @click="toggleSubMenu('scoreRelations')">
				<image class="icon" src="/static/KPI.png" />
				<text class="text">销售业绩评估</text>
			</view>

			<view class="sub-menu" v-if="activeMenu.scoreRelations">
				<view class="sub-menu-item" @click="goToManagePage">
					<image class="icon" src="/static/分析报表.png" />
					<text class="text">业绩概览</text>
				</view>
				<view class="sub-menu-item" @click="goToInteractionPage">
					<image class="icon" src="/static/人员业绩.png" />
					<text class="text">人员业绩</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// 为了实现两个子模块可以同时展开，需要对菜单项的状态进行单独处理。所以将 activeMenu 定义为一个对象，来跟踪每个菜单项的展开状态
				activeMenu: {
					customerRelations: false,
					scoreRelations: false
				},
			};
		},
		methods: {
			toggleSubMenu(menu) {
				this.$set(this.activeMenu, menu, !this.activeMenu[menu]);
			},
			goBack() {
				uni.navigateBack();
			},
			goToManagePage() {
				uni.navigateTo({
					url: "/pages/me/manage"
				})
			},
			goToInteractionPage() {
				uni.navigateTo({
					url: "/pages/me/interaction"
				})
			},
			goToFacePage() {
				uni.navigateTo({
					url: "/pages/me/detail"
				})
			}
		}
	};
</script>

<style>
	.container {
		padding: 5px;
	}

	.header {
		display: flex;
		align-items: center;
		margin-bottom: 16px;
	}

	.back-icon {
		font-size: 20px;
		margin-right: 8px;
		cursor: pointer;
	}

	.title {
		font-size: 24px;
		font-weight: bold;
	}

	.menu {
		display: flex;
		flex-direction: column;
	}

	.menu-item {
		display: flex;
		align-items: center;
		padding: 8px;
		border-bottom: 1px solid #ccc;
		cursor: pointer;
	}

	.sub-menu {
		padding-left: 30px;
	}

	.sub-menu-item {
		display: flex;
		align-items: center;
		padding: 8px 0;
	}

	.icon {
		width: 20px;
		height: 20px;
		margin-right: 12px;
	}

	.text {
		font-size: 13px;
	}
</style>